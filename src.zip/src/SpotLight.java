
public class SpotLight {
	int r = 255;
	int g = 8;
	int b = 8;
	Point3D coordinates = new Point3D(10,-10,10);
	double power = 1;
	
	

	public int getR() {
		return r;
	}

	public int getG() {
		return g;
	}

	public int getB() {
		return b;
	}

	public double getCos(double x2, double y2, double z2) {
		double X = coordinates.getX();
		double Y = coordinates.getY();
		double Z = coordinates.getZ();
		double mul = (x2*X) + (y2*Y) + (z2*Z);
		double length1 = Math.sqrt(X*X+Y*Y+Z*Z);
		double length2 = Math.sqrt(x2*x2+y2*y2+z2*z2);
		return Math.abs(mul/(length1*length2));
	}
	
}
