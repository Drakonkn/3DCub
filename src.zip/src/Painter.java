import java.awt.Color;
import java.awt.Graphics;
import java.util.Collections;
import java.util.Vector;

import javax.swing.JPanel;


public class Painter extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Model model;
	
	public Painter() {
		model = new Model();
		setBackground(new Color(0x000000));
		setDoubleBuffered(true);
	}

	public void setModel(Model model) {
		this.model = model;
	}

	protected void paintComponent(Graphics g){
		
		    super.paintComponent(g);
		    
//		    int width = arrayModel.length;
//		    int height = arrayModel[0].length;
//		    
//		    
//		    for(int i = 0; i<width;i++)
//		    	for(int j = 0;j<height;j++){
//		    		g.setColor(new Color(0x555555));
//		    		g.setColor(arrayModel[i][j]);
//		    		g.drawRect(i, j, 1, 1);
//		    		//g.drawLine(i, j, i, j);
//		    	}
		    
		    
		    double resize = 15;
		    double move = -500;
		Vector<triangle> vector =  model.getVector();
		Collections.sort(vector, new ZCompporator());
		for (int i = 0; i<vector.size();i++) {
			int[] x = {(int)(vector.get(i).A2.getX()*resize+move),
					(int)(vector.get(i).B2.getX()*resize+move),
					(int)(vector.get(i).C2.getX()*resize+move)};
			int[] y = {(int)(vector.get(i).A2.getY()*resize+move),
					(int)(vector.get(i).B2.getY()*resize+move),
					(int)(vector.get(i).C2.getY()*resize+move)};
			g.setColor(vector.get(i).color);
			g.fillPolygon(x, y, 3);
			//drawTriangle(g,x[0],y[0],x[1],y[1],x[2],y[2]);
//			g.setColor(new Color(0xCCCCCC));
//			g.drawLine(x[0], y[0],x[1],y[1]);
//			g.drawLine(x[1], y[1],x[2], y[2]);
//			g.drawLine(x[2], y[2],x[0],y[0]);
					
		}
	}


	void drawTriangle(Graphics g, int x1, int y1, int x2, int y2, int x3, int y3)
	{
		if (y2 < y1) {
			int t;
			t = y1;
			y1 = y2;
			y2 = t;
			
			t = x1;
			x1 = x2;
			x2 = t;
			
		} 
		if (y3 < y1) {
			
			int t;
			t = y1;
			y1 = y3;
			y3 = t;
			
			t = x1;
			x1 = x3;
			x3 = t;
		}
		if (y2 > y3) {
			int t;
			t = y2;
			y2 = y3;
			y3 = t;
			
			t = x2;
			x2 = x3;
			x3 = t;
		}

		float dx13 = 0, dx12 = 0, dx23 = 0;
		if (y3 != y1) {
			dx13 = x3 - x1;
			dx13 /= y3 - y1;
		}
		else
		{
			dx13 = 0;
		}

		if (y2 != y1) {
			dx12 = x2 - x1;
			dx12 /= (y2 - y1);
		}
		else
		{
			dx12 = 0;
		}

		if (y3 != y2) {
			dx23 = x3 - x2;
			dx23 /= (y3 - y2);
		}
		else
		{
			dx23 = 0;
		}

		float wx1 = x1;
		float wx2 = wx1;
		
		float _dx13 = dx13;

		if (dx13 > dx12)
		{
			float t;
			t = dx13;
			dx13 = dx12;
			dx12 = t;
		}

		for (int i = y1; i < y2; i++){
			for (int j = (int)(wx1); j <= (int)(wx2); j++){
				//SetPixel(hdc, j, i, 0);
				g.drawRect(j, i, 1, 1);
			}
			wx1 += dx13;
			wx2 += dx12;
		}
		if (y1 == y2){
			wx1 = x1;
			wx2 = x2;
		}
		if (_dx13 < dx23)
		{
			float t;
			t = _dx13;
			_dx13 = dx23;
			dx23 = t;
		}
		
		for (int i = y2; i <= y3; i++){
			for (int j = (int)(wx1); j <= (int)(wx2); j++){
				g.drawRect(j, i, 1, 1);
			}
			wx1 += _dx13;
			wx2 += dx23;
		}
	}
	 
}
